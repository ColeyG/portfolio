﻿# fullCanvasSplash
fullCanvasSplash is an attempt at making a small site with a focus point of canvas design elements at any size. This project when paired with any library of works could make for a nice portfolio or a place to play around with interesting 2d/3d web spec. The design is intended to be spartan and focuses on the animation work written in js.
