(function(){
    function redir(){
        window.location.href="index.php";
    }
    redir();
})();
